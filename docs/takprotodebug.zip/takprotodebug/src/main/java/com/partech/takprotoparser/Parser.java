/***************************************************************************
 *  Copyright 2019 PAR Government Systems
 *
 * Restricted Rights:
 * Use, reproduction, or disclosure of executable code, application interface
 * (API), source code, or related information is subject to restrictions set
 * forth in the contract and/or license agreement.    The Government's rights
 * to use, modify, reproduce, release, perform, display, or disclose this
 * software are restricted as identified in the purchase contract. Any
 * reproduction of computer software or portions thereof marked with this
 * legend must also reproduce the markings. Any person who has been provided
 * access to this software must be aware of the above restrictions.
 *
 * Permission has been granted for use within the ATAK application.
 */

package com.partech.takprotoparser;

import atakmap.commoncommo.protobuf.v1.Takmessage.TakMessage;

import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.nio.ByteBuffer;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.UnknownHostException;

public class Parser {

    private static String INET_ADDR = "239.2.3.1";
    private static int PORT = 6969;
    private static String FILE_NAME;

    public static void main(String[] args) {


        if (args.length == 1) {
            FILE_NAME = args[0];

        } else if (args.length == 2) {
            try {
                INET_ADDR = args[0];
                PORT = Integer.parseInt(args[1]);

            } catch (Exception e) {
            }
        }

        if (FILE_NAME == null) {
            System.out.println("starting up network listening: " + INET_ADDR + ":" + PORT);
        } else {
            System.out.println("starting up file parsing: " + FILE_NAME);
        }

        if (FILE_NAME != null) {
            try {
                FileInputStream fis = new FileInputStream(new File(FILE_NAME));

                byte[] arr = new byte[64 * 1024];
                int len = fis.read(arr);
                TakMessage message = TakMessage.parseFrom(
                        ByteBuffer.wrap(arr,
                                 3,
                                len - 3));
                System.out.println(message.toString());

            } catch (Exception e) {
                System.out.println("error reading file: " + FILE_NAME);
                e.printStackTrace();
            }


            return;
        }
        try {

            InetAddress address = InetAddress.getByName(INET_ADDR);
            byte[] buf = new byte[4096];
            DatagramPacket msgPacket = new DatagramPacket(buf, buf.length);

            MulticastSocket clientSocket;
            try {
                clientSocket = new MulticastSocket(null);
                clientSocket.setReuseAddress(true);
                clientSocket.bind(new InetSocketAddress(address, PORT));
                clientSocket.joinGroup(address);

                while (true) {
                    clientSocket.receive(msgPacket);

                    // according to protocol.txt (magic number, version, magic number, payload)
            try { 
                        TakMessage message = TakMessage.parseFrom(
                            ByteBuffer.wrap(msgPacket.getData(),
                                    msgPacket.getOffset() + 3,
                                    msgPacket.getLength() - 3));
                        System.out.println(message.toString());
                    } catch (Exception e) { 
                        byte[] data = Arrays.copyOfRange(
                                msgPacket.getData(), msgPacket.getOffset(),
                                msgPacket.getLength());
                        String s = new String(data);
                        if (s.startsWith("<")) {
                            System.out.println(s);
                        } else { 
                            System.out.println("error[" + msgPacket.getLength() + "]: " + Arrays.toString(data));
                        }
                    }             

                }
            } catch (Exception ex) {
                System.out.println("error[" + msgPacket.getLength() + "]: "
                        + Arrays.toString(Arrays.copyOfRange(
                                msgPacket.getData(), msgPacket.getOffset(),
                                msgPacket.getLength())));
                ex.printStackTrace();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }
}
